<?php 
$developer_name = "John Doe";
$age = 20;
$is_senior = false;
$salary = 50000.00;

echo "Developer name is " . $developer_name . " and age is " . $age . "<br>";

var_dump($is_senior);

var_dump($salary);

$database_user_id = 100;
$login_user_id = '100';
if($database_user_id === $login_user_id) {
    echo "User ID matches.";
} else {
    echo "User ID does not match.";
}

echo ($database_user_id == $login_user_id) ?"true":"false";


class BankAccount {
    protected string $account_holdername;
    protected float $balance;
    public function __construct(string $name , float $initial_balance) {
        $this->account_holdername = $name;
        $this->balance = $initial_balance;
    }

    public function deposit(float $amount)
    {
        if ($amount > 0) {
            $this->balance += $amount;
            echo "Deposit successful. New balance: " . $this->balance;
        }
    }

    public function withdraw(float $amount)
    {
        if ($amount > 0 && $amount <= $this->balance) {
            $this->balance -= $amount;
            echo "Withdrawal successful. New balance: " . $this->balance;
        } else {
            echo "Insufficient funds or invalid amount.";
        }
    }
    public function getBalance() :float{
        return $this->balance;
        
    }




}

$bank = new BankAccount("Kyaw min", 1000.00);

$bank->withdraw(200.00);


?>
