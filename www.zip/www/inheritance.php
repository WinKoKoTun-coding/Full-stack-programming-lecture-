<?php 
namespace App\Models\Managements;

class User{
    protected string $name , $email;
    public function __construct(string $name , string $email)
    {
        $this->name = $name;
        $this->email = $email;
    }

    public function getDetails(): string
    {
        return "Name: " . $this->name . ", Email: " . $this->email;
    }

}

class Admin extends User{
    private string $role;
   public function __construct(string $name ,string $email, string $role){
    parent::__construct($name , $email);
    $this->role = $role;
   }

    public function checkIsAdmin(): string
    {
        if ($this->role == "admin") {
            return parent::getDetails();
        } else {
            return "User is not an admin.";
        }
    }
    
}

