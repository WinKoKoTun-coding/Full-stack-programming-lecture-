<?php
 use App\Models\Managements\Admin;

 $admin = new Admin("zhen",'admin.com','user');
 echo $admin->checkIsAdmin();



 