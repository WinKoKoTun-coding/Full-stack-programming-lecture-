const express = require('express')

const app = express()

app.set('views','./views')
app.set('view engine','ejs')



app.use(express.static("public"))

app.get('/about',(req,res)=>{
    // res.sendFile('./views/about.html',{root:__dirname})
    // res.setHeader("Location",'./views/about.html')
    res.render('about')
})


app.listen('3000',()=>{
    console.log("Server is running on port 3000...!")
})
