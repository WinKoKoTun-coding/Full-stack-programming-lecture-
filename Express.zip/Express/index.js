const express = require('express')

const app = express()

app.set('views','./views')
app.set('view engine','ejs')

app.get('/',(req,res)=>{
    // res.sendFile('./views/home.html',{root:__dirname})

    const blogs =[
    { title : 'titleone', message : 'hello1'},
    { title : 'titletwo', message : 'hello2'},
    { title : 'titlethree', message : 'hello3'},   
    { title : 'titlefour', message : 'hello4'}
]


    res.render('home',{mess : "<h2>Hello world </h2>"})
})

app.get('/about',(req,res)=>{
    // res.sendFile('./views/about.html',{root:__dirname})
    // res.setHeader("Location",'./views/about.html')
    res.render('about')
})

app.get('/contact',(req,res)=>{
    // res.sendFile('./views/contact.html',{root:__dirname})
    res.render('contact')
})

app.get('/contact-us',(req,res)=>{
    // res.sendFile('./views/contact.html',{root:__dirname})
    res.redirect('/contact')
})

app.get('/contacts',(req,res)=>{
    // res.sendFile('./views/contact.html',{root:__dirname})
    res.redirect('/contact')
})

app.use((req,res)=>{
    // res.sendFile('./views/404page.html',{root:__dirname})
    res.render('404page')
})

app.listen('3000',()=>{
    console.log("Server is running on port 3000...!")
})