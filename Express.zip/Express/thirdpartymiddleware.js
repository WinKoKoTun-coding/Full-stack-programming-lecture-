const express = require('express')

const app = express()

const morgan = require('morgan')

app.set('views','./views')
app.set('view engine','ejs')

const middlefun = (data) =>{
    return(req,res,next)=>{
        if(data == 'codelab'){
            console.log(`${req.method} + ${req.originalUrl}`);
             
           
        }
        
        next()
        res.end()
        
    }
}

app.use(middlefun('codelab'));

app.use(()=>{
    console.log("terminated program ...")
})

app.get('/about',(req,res)=>{
    // res.sendFile('./views/about.html',{root:__dirname})
    // res.setHeader("Location",'./views/about.html')
    res.render('about')
})

app.listen('3000');