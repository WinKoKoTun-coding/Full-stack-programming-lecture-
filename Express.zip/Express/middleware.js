const express = require('express')

const app = express()

const morgan = require('morgan')

app.set('views','./views')
app.set('view engine','ejs')

app.use((req,res,next)=>{
    console.log("Middleware is running ....")
    console.log(morgan('tiny'))
    next();
})

app.get('/about',(req,res)=>{
    // res.sendFile('./views/about.html',{root:__dirname})
    // res.setHeader("Location",'./views/about.html')
    res.render('about')
})

app.listen('3000');